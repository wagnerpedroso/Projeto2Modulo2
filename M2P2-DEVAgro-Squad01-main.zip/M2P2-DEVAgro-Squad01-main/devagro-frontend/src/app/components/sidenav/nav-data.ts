export const navbarData = [
  {
    routeLink: '/admin',
    //icon: "fal fa-home",
    label: "Início",
    pathImgHome: true
  },
  {
    routeLink: '/admin/funcionarios',
    //icon: "fal fa-users",
    label: "Funcionários",
    pathImgFunc: true
  },
  {
    routeLink: '/admin/fazendas',
    //icon: "fal fa-university",
    label: "Fazendas",
    pathImgArmazem: true
  },
  {
    routeLink: '/admin/graos',
    //icon: "fal fa-tree",
    label: "Grãos",
    pathImgMilho: true
  },
];
