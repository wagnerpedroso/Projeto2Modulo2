import { Object } from './grao';

export const GRAOS: Object[] = JSON.parse(String(localStorage.getItem("listaGraos"))); 