export interface Object {
    id: number;
    nome: string;
    fazenda: string;
    colheita: string;
    informacao: string;
  }
