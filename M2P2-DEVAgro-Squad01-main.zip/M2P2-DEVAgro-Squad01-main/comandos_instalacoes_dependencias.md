## Instalando angular material e gerando dashboard

```bash
ng add @angular/material

ng generate @angular/material:dashboard components/admin/pages/dashboard
```