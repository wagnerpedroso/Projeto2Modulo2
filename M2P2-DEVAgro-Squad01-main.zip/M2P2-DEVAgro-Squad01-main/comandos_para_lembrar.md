para posicionar pasta:
cd devagro-frontend

para iniciar:
ng s